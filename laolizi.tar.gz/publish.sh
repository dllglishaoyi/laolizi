#!/bin/bash
tar zcvf laolizi.tar.gz ./
scp laolizi.tar.gz root@121.199.29.58:/tmp/laolizi.tar.gz
# scp portage.tar.gz yangqing@itouchchina.com:/tmp/